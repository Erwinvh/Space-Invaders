#ifndef CORE_H
#define CORE_H

//Boolean
#define true 1
#define false 0

//The method to start the program
int coreStart(void);

#endif